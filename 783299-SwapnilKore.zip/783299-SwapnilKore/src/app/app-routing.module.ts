import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlayersComponent } from './players/players.component';
import {PlayerDataComponent} from './player-data/player-data.component'

const routes: Routes = [
  {path:'players',component:PlayersComponent},
  // new added last 3
  {path:'players/:id/:name/:country/:dob/:role/:battingStyle/:bowlingStyle/:img/:img1/:img2/:img3',component:PlayerDataComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
