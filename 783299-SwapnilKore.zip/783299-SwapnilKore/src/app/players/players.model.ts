export class PlayerModel{
    id: number=0;
    name:string='';
    country:string='';
    dob:string='';
    role:string='';
    battingStyle:string='';
    bowlingStyle:string='';
    img: string='';
    // new added
    img1: string='';
    img2: string='';
    img3: string='';
}