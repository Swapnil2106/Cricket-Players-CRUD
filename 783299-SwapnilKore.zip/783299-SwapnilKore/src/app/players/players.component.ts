import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import {Router} from '@angular/router';
import { PlayerModel } from './players.model';

@Component({
  selector: 'app-players',
  templateUrl: './players.component.html',
  styleUrls: ['./players.component.css']
})
export class PlayersComponent {

  formValue !: FormGroup;
  playerModeloBJ: PlayerModel = new PlayerModel();
  playerData: any;
  showAdd!:boolean;
  showUpdate!:boolean;

  constructor(private formBuilder: FormBuilder, private api: ApiService, private router:Router) {  }

  ngOnInit() {
    this.formValue = this.formBuilder.group({
      name: [''],
      country: [''],
      dob: [''],
      role: [''],
      battingStyle: [''],
      bowlingStyle: [''],
      img: [''],
      // new added
      img1:[''],
      img2:[''],
      img3:['']
    });
    this.getAllPlayers();
  }
 
  getAllPlayers() {
    this.api.getPlayers().subscribe(
      res => {
        this.playerData = res;
      }
    )
  }

  fetchPlayer(player:any)
  {
    // new added last 3
    this.router.navigate(['/players',player.id,player.name,player.country,player.dob,player.role,player.battingStyle,player.bowlingStyle,player.img,player.img1,player.img2,player.img3]);
  }

  deletePlayer(emp: any) {
    this.api.deletePlayerapi(emp.id).subscribe(
      res => {
        alert("Player deleted!!!!");
        this.getAllPlayers();
      }
    )
  }

  clickAddPlayer()
  {
    this.formValue.reset();
    this.showAdd=true;
    this.showUpdate=false;
  }

  postPlayerDetails() {
    this.playerModeloBJ.name = this.formValue.value.name;
    this.playerModeloBJ.country = this.formValue.value.country;
    this.playerModeloBJ.dob = this.formValue.value.dob;
    this.playerModeloBJ.role = this.formValue.value.role;
    this.playerModeloBJ.battingStyle = this.formValue.value.battingStyle;
    this.playerModeloBJ.bowlingStyle = this.formValue.value.bowlingStyle;
    this.playerModeloBJ.img = `${this.playerModeloBJ.name}.png`;
    // new added
    this.playerModeloBJ.img1 = `${this.playerModeloBJ.name}1.jpg`;
    this.playerModeloBJ.img2 = `${this.playerModeloBJ.name}2.jpg`;
    this.playerModeloBJ.img3 = `${this.playerModeloBJ.name}3.jpg`;

    this.api.postPlayer(this.playerModeloBJ).subscribe(res => {
      console.log(res);
      alert("Player Added Successfully");
      this.getAllPlayers();
      let close = document.getElementById("cancel");
      close?.click();
      this.formValue.reset();
    },
      err => {
        alert("Something went Wrong !!!!!");
      });
  }

  editPlayer(data: any) {
    this.playerModeloBJ.id = data.id;
    this.showAdd=false;
    this.showUpdate=true;

    this.formValue.controls['name'].setValue(data.name);
    this.formValue.controls['country'].setValue(data.country);
    this.formValue.controls['dob'].setValue(data.dob);
    this.formValue.controls['role'].setValue(data.role);
    this.formValue.controls['battingStyle'].setValue(data.battingStyle);
    this.formValue.controls['bowlingStyle'].setValue(data.bowlingStyle);
    this.formValue.controls['img'].setValue(data.img);
    // new added
    this.formValue.controls['img1'].setValue(data.img1);
    this.formValue.controls['img2'].setValue(data.img2);
    this.formValue.controls['img3'].setValue(data.img3);
  }

  updatePlayerDetails() {
    this.playerModeloBJ.name = this.formValue.value.name;
    this.playerModeloBJ.country = this.formValue.value.country;
    this.playerModeloBJ.dob = this.formValue.value.dob;
    this.playerModeloBJ.role = this.formValue.value.role;
    this.playerModeloBJ.battingStyle = this.formValue.value.battingStyle;
    this.playerModeloBJ.bowlingStyle = this.formValue.value.bowlingStyle;
    this.playerModeloBJ.img = `${this.playerModeloBJ.name}.png`;
    // new added
    this.playerModeloBJ.img1 = `${this.playerModeloBJ.name}1.jpg`;
    this.playerModeloBJ.img2 = `${this.playerModeloBJ.name}2.jpg`;
    this.playerModeloBJ.img3 = `${this.playerModeloBJ.name}3.jpg`;

    this.api.updatePlayer(this.playerModeloBJ,this.playerModeloBJ.id).subscribe(res => {
      console.log(res);
      alert("Employee Updated Successfully");
      this.getAllPlayers();
      let close = document.getElementById("cancel");
      close?.click();
      this.formValue.reset();
    },
      err => {
        alert("Something went Wrong !!!!!");
      });
  }
}
