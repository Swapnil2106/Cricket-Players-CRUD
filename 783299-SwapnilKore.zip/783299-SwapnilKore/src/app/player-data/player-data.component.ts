import { Component } from '@angular/core';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-player-data',
  templateUrl: './player-data.component.html',
  styleUrls: ['./player-data.component.css']
})
export class PlayerDataComponent {

  public playerid:any;
  public playername:any;
  public playercountry:any;
  public playerdob:any;
  public playerrole:any;
  public playerbattingStyle:any;
  public playerbowlingStyle:any;
  public playerimg:any;
  // new added
  public playerimg1:any;
  public playerimg2:any;
  public playerimg3:any;

  constructor(private route:ActivatedRoute)
  {

  }

  ngOnInit()
  {
    let id = this.route.snapshot.paramMap.get('id');
    this.playerid = id;

    let name = this.route.snapshot.paramMap.get('name');
    this.playername = name;

    let country = this.route.snapshot.paramMap.get('country');
    this.playercountry = country;

    let dob = this.route.snapshot.paramMap.get('dob');
    this.playerdob = dob;

    let role = this.route.snapshot.paramMap.get('role');
    this.playerrole = role;

    let battingStyle = this.route.snapshot.paramMap.get('battingStyle');
    this.playerbattingStyle = battingStyle;

    let bowlingStyle = this.route.snapshot.paramMap.get('bowlingStyle');
    this.playerbowlingStyle = bowlingStyle;

    let img = this.route.snapshot.paramMap.get('img');
    this.playerimg = img;

    //new added
    let img1 = this.route.snapshot.paramMap.get('img1');
    this.playerimg1 = img1;
    let img2 = this.route.snapshot.paramMap.get('img2');
    this.playerimg2 = img2;
    let img3 = this.route.snapshot.paramMap.get('img3');
    this.playerimg3 = img3;
  }
}
